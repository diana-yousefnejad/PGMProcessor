#include <stdio.h>
#include <stdlib.h>

// Structure to hold grayscale pixel data
typedef struct {
    unsigned char value;
} PixelGray;

// Function to read a PGM image into a 2D array
PixelGray** readPGM(const char* filename, int* width, int* height) {
    FILE *input = NULL; //file pointer declaration (input)
    input = fopen(filename, "r"); //open file
    printf("opened");

    if (input == NULL) { //handle error for opening
        printf("Unable to open lenna.pgm\n");
        exit(1);
    }

    char firstLine[3];
    int size;

    fscanf(input, "%2s", firstLine); //reads P5
    printf("P5: %s",firstLine);

    fscanf(input, "%d %d", height, width); //reads dimensions
    printf("height: %d",*height);
    printf("width: %d",*width);

    fscanf(input, "%d", &size); //reads 255
    printf("size: %d",size);

    fgetc(input);

    //allocate memory
    PixelGray **matrix = (PixelGray **) malloc(*height * sizeof(PixelGray **));
    printf("allocated memory"); //works
    //handle error
    if (matrix == NULL) { //handles error
        printf("error, can not allocate memory because matrix is null");
    }

    //allocates memory
    for (int i = 0; i < *height; i++) {
        matrix[i] = (PixelGray *) malloc(*width * sizeof(PixelGray **));
        //printf("hi");
        if (matrix[i] == NULL) {
            printf("Error: Unable to allocate memory for columns in row %d\n", i);
        }
    }
int count = 0;

    //read from file and fill matrix
    for (int i = 0; i < *height; i++) {
        for (int j = 0; j < *width; j++) {
             fread(&matrix[i][j].value, sizeof(char), 1, input);
            //printf("%d ",matrix[i][j].value);
            count++;

        }
    }
    printf("%d",count); //checks count for pixels

    fclose(input); //close file

    return matrix;

}

// Function to write a 2D matrix as a PGM image
void writePGM(const char* filename, PixelGray** matrix, int* width, int* height){

FILE *newFile = fopen(filename, "w");
if (newFile == NULL){
    printf("error, can not open file");
}

fprintf(newFile,"%2s\n", "P5"); //prints P5 into file
fprintf(newFile,"%d %d\n", *height, *width); //prints dimensions into file
fprintf(newFile,"%d\n", 255); //prints 255 into file

//fills file with matrices values
for (int i = 0; i< *height; i++) {
    for (int j = 0; j < *width; j++) {
        fputc(matrix[i][j].value, newFile);
    }
}

fclose(newFile); //close file
}


// Function to threshold the image matrix
PixelGray** threshold(PixelGray** matrix, int* width, int* height){

    //allocate memory for new matrix
PixelGray **newMatrix = (PixelGray **) malloc(*height * sizeof(PixelGray *));
    printf("allocated memory"); //works

    //handle error
    if (newMatrix == NULL) {
        printf("error, can not allocate memory because matrix is null");
    }

    for (int i = 0; i < *height; i++) {
        newMatrix[i] = (PixelGray *) malloc(*width * sizeof(PixelGray *));
        if (newMatrix[i] == NULL) {
            printf("Error: Unable to allocate memory for columns in row %d\n", i);
        }
    }

    for (int i = 0; i < *height; i++) {
        for (int j = 0; j < *width; j++) {
            //checks if old matrix value is greater than 80: makes that value in new matrix 255
            if (matrix[i][j].value > 80 ) {
                newMatrix[i][j].value = 255;
                //printf("%d ",newMatrix[i][j].value);
            }
                //else makes that value in new matrix 0
            else {
                newMatrix[i][j].value = 0;
                //printf("%d ",newMatrix[i][j].value);
            }
        }
    }

return newMatrix;
}

// Function to rotate the image matrix
PixelGray** rotate(PixelGray** matrix, int* width, int* height){
//allocate memory for new matrix
 PixelGray **newMatrix = (PixelGray **) malloc(*height * sizeof(PixelGray *));
    printf("allocated memory"); //works
//handle error
    if (newMatrix == NULL) {
        printf("error, can not allocate memory because matrix is null");
    }

    for (int i = 0; i < *height; i++) {
        newMatrix[i] = (PixelGray *) malloc(*width * sizeof(PixelGray *));
        if (newMatrix[i] == NULL) {
            printf("Error: Unable to allocate memory for columns in row %d\n", i);
        }
    }
    //swaps rows and columns in order to rotate
    for (int i = 0; i < *height; i++) {
        for (int j = 0; j < *width; j++) {
        newMatrix[i][j].value = matrix[j][i].value;
        }
        }
        return newMatrix;
}


//main function - DO NOT MODIFY
int main() {
    int width, height;  // variable to hold width and height. Use reference in other functions

    PixelGray** image_original = readPGM("lenna.pgm", &width, &height);

    //printf("-----");

       // Now you have the grayscale image data in the 'image_original' 2D array

       // Access pixel data using image[row][col].value
       // For example, to access the pixel at row=2, col=3:
       //unsigned char pixel_value = image[2][3].value;

    // Create a new 2D array 'image_thresh' to store the threshold image
    PixelGray** image_thresh = threshold(image_original, &width, &height);
       //write the image data as "threshold.pgm"
    //writePGM("threshold.pgm", image_original, &width, &height);
      writePGM("threshold.pgm", image_thresh, &width, &height);

       // Create a new 2D array 'image_rotate' to store the rotated image
    PixelGray** image_rotate = rotate(image_original, &width, &height);
       //write the image data as "rotate.pgm"
      writePGM("rotate.pgm", image_rotate, &width, &height);

     image_rotate = rotate(image_rotate, &width, &height);
       //write the image data as "rotate_again.pgm"
     writePGM("rotate_again.pgm", image_rotate, &width, &height);

       // Free the allocated memory when you're done

     for (int i = 0; i < height; ++i) {
           free(image_original[i]);
         free(image_thresh[i]);
          free(image_rotate[i]);
       }
       free(image_original);
     free(image_thresh);
      free(image_rotate);
       return 0;





}

